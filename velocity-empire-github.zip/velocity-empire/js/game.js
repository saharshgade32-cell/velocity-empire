// ======================= CAR DATA =======================
const CAR_DEFS = [
  { id:'civic',   name:'Honda Civic Type R',      emoji:'🚗',  color:0x1155ff, topSpeed:480,  accel:55,  handling:0.055, mass:1.0,  carType:'sedan'   },
  { id:'mustang', name:'Shelby GT500',             emoji:'🏎️', color:0xdd2200, topSpeed:560,  accel:72,  handling:0.048, mass:1.05, carType:'muscle'  },
  { id:'m3',      name:'BMW M4 CSL',               emoji:'🚙',  color:0xffffff, topSpeed:620,  accel:85,  handling:0.058, mass:0.95, carType:'sport'   },
  { id:'ferrari', name:'Ferrari SF90',             emoji:'🏎️', color:0xff1100, topSpeed:720,  accel:105, handling:0.062, mass:0.85, carType:'ferrari' },
  { id:'lambo',   name:'Lamborghini Aventador',    emoji:'🏎️', color:0xffdd00, topSpeed:800,  accel:120, handling:0.060, mass:0.82, carType:'lambo'   },
  { id:'bugatti', name:'Bugatti Bolide',           emoji:'🚀',  color:0x0033cc, topSpeed:1000, accel:160, handling:0.055, mass:0.88, carType:'bugatti' },
];

const TRACK_DEFS = [
  { id:'city', name:'City Circuit', laps:3, reward:2000, color:0x334455 },
  { id:'desert', name:'Desert Track', laps:3, reward:3500, color:0x886622 },
  { id:'night', name:'Night Race', laps:3, reward:5000, color:0x111122 },
];

// ======================= GLOBALS =======================
let scene, camera, renderer, clock;
let playerCar, aiCars = [];
let keys = {};
let selectedCarId = 'civic';
let selectedTrackId = 'city';
let cash = 2000;
let raceStarted = false, raceEnded = false;
let raceStartTime = 0, currentLap = 1, totalLaps = 3;
let lapStartTime = 0, bestLap = Infinity;
let playerProgress = 0;
let camMode = 0; // 0=chase, 1=hood, 2=orbit

// Physics state
let carVelocity, carSpeed = 0, carAngle = 0;
let wheelAngle = 0;
let nitro = 100, nitroCooldown = false;
let rpmVal = 0, gearVal = 1;
let enginePitch = 0;

// Track waypoints (circuit)
let trackPoints = [];
let trackMesh, roadObjects = [];
let groundMesh;

// Minimap
let minimapCtx;

// Touch joystick state (also used on desktop as 0)
let joystickDX = 0, joystickDY = 0;

// ======================= SETUP START SCREEN =======================
function setupStartScreen() {
  // Detect device and show relevant control hint
  const isTouch = (navigator.maxTouchPoints > 0 || 'ontouchstart' in window);
  const hasGamepad = 'getGamepads' in navigator;
  const isMac = /Mac|iPhone|iPad/.test(navigator.platform || navigator.userAgent);
  const info = document.getElementById('controls-info');
  if (info) {
    if (isTouch) {
      info.innerHTML = '🕹️ Joystick to steer &amp; accelerate &nbsp;·&nbsp; ⚡ Nitro button &nbsp;·&nbsp; 📐 Tap TILT for gyro steering<br>🎮 Plug in a controller for the best experience';
    } else {
      info.innerHTML = '⌨️ <b>W/S</b> Accelerate/Brake &nbsp;·&nbsp; <b>A/D</b> Steer &nbsp;·&nbsp; <b>SHIFT</b> Nitro &nbsp;·&nbsp; <b>SPACE</b> Handbrake<br><b>R</b> Reset &nbsp;·&nbsp; <b>C</b> Camera &nbsp;&nbsp;|&nbsp;&nbsp; 🎮 Controller supported';
    }
  }
  const cs = document.getElementById('carSelector');
  CAR_DEFS.forEach(car => {
    const div = document.createElement('div');
    div.className = 'car-option' + (car.id === selectedCarId ? ' active' : '');
    div.innerHTML = `
      <div class="co-emoji">${car.emoji}</div>
      <div class="co-name">${car.name}</div>
      <div class="co-stats">
        <div style="text-align:left;font-size:0.65rem;color:rgba(255,255,255,0.35)">Speed</div>
        <div class="co-stat-bar"><div class="co-stat-fill" style="width:${car.topSpeed/3}%"></div></div>
        <div style="text-align:left;font-size:0.65rem;color:rgba(255,255,255,0.35)">Accel</div>
        <div class="co-stat-bar"><div class="co-stat-fill" style="width:${car.accel/0.28}%"></div></div>
      </div>
    `;
    div.onclick = () => {
      selectedCarId = car.id;
      document.querySelectorAll('.car-option').forEach(el=>el.classList.remove('active'));
      div.classList.add('active');
    };
    cs.appendChild(div);
  });

  const ts = document.getElementById('track-selector');
  TRACK_DEFS.forEach(track => {
    const div = document.createElement('div');
    div.className = 'track-opt' + (track.id === selectedTrackId ? ' active' : '');
    div.textContent = track.name;
    div.onclick = () => {
      selectedTrackId = track.id;
      document.querySelectorAll('.track-opt').forEach(el=>el.classList.remove('active'));
      div.classList.add('active');
    };
    ts.appendChild(div);
  });
}

// ======================= THREE.JS INIT =======================
function initThree() {
  scene = new THREE.Scene();
  clock = new THREE.Clock();

  // Renderer - limit pixel ratio for iPad performance
  const isMobile = isTouchDevice();
  renderer = new THREE.WebGLRenderer({ canvas: document.getElementById('c'), antialias: !isMobile });
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, isMobile ? 1.5 : 2));
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = isMobile ? THREE.BasicShadowMap : THREE.PCFSoftShadowMap;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.2;

  // Camera
  camera = new THREE.PerspectiveCamera(70, window.innerWidth / window.innerHeight, 0.1, 2000);
  camera.position.set(0, 8, -18);

  // Resize
  window.addEventListener('resize', () => {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
  });

  // ---- HEMISPHERE LIGHT for ambient reflections ----
  const hemi = new THREE.HemisphereLight(0x9999ff, 0x334422, 0.5);
  scene.add(hemi);
}

// ======================= LIGHTING =======================
function setupLighting(trackId) {
  // Ambient
  const isNight = trackId === 'night';
  const ambient = new THREE.AmbientLight(isNight ? 0x111133 : 0x334466, isNight ? 0.4 : 0.8);
  scene.add(ambient);

  // Sun / Moon
  const sun = new THREE.DirectionalLight(isNight ? 0x4466aa : 0xfff5e0, isNight ? 0.5 : 2.0);
  sun.position.set(200, 400, 100);
  sun.castShadow = true;
  sun.shadow.mapSize.width = isTouchDevice() ? 1024 : 4096;
  sun.shadow.mapSize.height = isTouchDevice() ? 1024 : 4096;
  sun.shadow.camera.near = 1;
  sun.shadow.camera.far = 1000;
  sun.shadow.camera.left = -300;
  sun.shadow.camera.right = 300;
  sun.shadow.camera.top = 300;
  sun.shadow.camera.bottom = -300;
  sun.shadow.bias = -0.001;
  scene.add(sun);

  // Fill light
  const fill = new THREE.DirectionalLight(0x8899cc, 0.4);
  fill.position.set(-100, 100, -100);
  scene.add(fill);

  // Sky gradient
  if (isNight) {
    scene.background = new THREE.Color(0x020408);
    scene.fog = new THREE.FogExp2(0x050810, 0.005);
    // Add streetlights along track
    trackPoints.forEach((pt, i) => {
      if (i % 8 === 0) {
        const light = new THREE.PointLight(0xffaa44, 2, 60);
        light.position.set(pt.x + 8, 10, pt.z);
        scene.add(light);
        const poleGeo = new THREE.CylinderGeometry(0.1, 0.15, 10, 8);
        const poleMat = new THREE.MeshStandardMaterial({ color: 0x444444, roughness: 0.8 });
        const pole = new THREE.Mesh(poleGeo, poleMat);
        pole.position.set(pt.x + 8, 5, pt.z);
        pole.castShadow = true;
        scene.add(pole);
        const lampGeo = new THREE.SphereGeometry(0.3, 8, 6);
        const lampMat = new THREE.MeshStandardMaterial({ color: 0xffcc88, emissive: 0xffaa44, emissiveIntensity: 2 });
        const lamp = new THREE.Mesh(lampGeo, lampMat);
        lamp.position.set(pt.x + 8, 10.5, pt.z);
        scene.add(lamp);
      }
    });
    // Stars
    const starGeo = new THREE.BufferGeometry();
    const starCount = 3000;
    const positions = new Float32Array(starCount * 3);
    for (let i = 0; i < starCount; i++) {
      positions[i*3] = (Math.random()-0.5)*2000;
      positions[i*3+1] = 100 + Math.random()*300;
      positions[i*3+2] = (Math.random()-0.5)*2000;
    }
    starGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    const starMat = new THREE.PointsMaterial({ color: 0xffffff, size: 0.5 });
    scene.add(new THREE.Points(starGeo, starMat));
  } else if (trackId === 'desert') {
    scene.background = new THREE.Color(0xd4903a);
    scene.fog = new THREE.Fog(0xd4903a, 100, 600);
  } else {
    scene.background = new THREE.Color(0x4a7ab5);
    scene.fog = new THREE.Fog(0x7aabde, 100, 500);
    // Clouds
    for (let i = 0; i < 20; i++) {
      const cloudGeo = new THREE.SphereGeometry(15 + Math.random()*20, 8, 6);
      const cloudMat = new THREE.MeshStandardMaterial({ color: 0xffffff, transparent: true, opacity: 0.85, roughness: 1 });
      const cloud = new THREE.Mesh(cloudGeo, cloudMat);
      cloud.position.set((Math.random()-0.5)*400, 60+Math.random()*40, (Math.random()-0.5)*400);
      cloud.scale.y = 0.4;
      scene.add(cloud);
    }
  }
}

// ======================= TRACK GENERATION =======================
function generateTrackPoints() {
  // Generate a smooth oval/circuit track
  trackPoints = [];
  const segments = 60;
  const radiusX = 180;
  const radiusZ = 120;
  const chicaneLocs = [0.15, 0.35, 0.65, 0.85]; // positions along track for chicanes

  for (let i = 0; i < segments; i++) {
    const t = i / segments;
    const angle = t * Math.PI * 2;
    let x = Math.cos(angle) * radiusX;
    let z = Math.sin(angle) * radiusZ;
    // Add chicane variation
    const chicaneAmt = chicaneLocs.reduce((acc, cl) => {
      const dist = Math.abs(t - cl);
      if (dist < 0.06) return acc + Math.sin((dist/0.06) * Math.PI) * 18 * Math.cos(angle);
      return acc;
    }, 0);
    x += chicaneAmt;
    trackPoints.push(new THREE.Vector3(x, 0, z));
  }
  trackPoints.push(trackPoints[0].clone()); // close loop

  return trackPoints;
}

function buildTrack(trackId) {
  const trackDef = TRACK_DEFS.find(t=>t.id===trackId);
  const isNight = trackId === 'night';
  const isDesert = trackId === 'desert';

  const roadWidth = 16;

  // Ground plane
  const groundColor = isNight ? 0x0a0e18 : isDesert ? 0x8b6820 : 0x2d5a1b;
  const groundGeo = new THREE.PlaneGeometry(1200, 1200, 50, 50);
  const groundMat = new THREE.MeshStandardMaterial({
    color: groundColor,
    roughness: 0.95, metalness: 0.0
  });
  groundMesh = new THREE.Mesh(groundGeo, groundMat);
  groundMesh.rotation.x = -Math.PI / 2;
  groundMesh.receiveShadow = true;
  scene.add(groundMesh);

  // Road surface using tube-like approach with CatmullRomCurve3
  const curve = new THREE.CatmullRomCurve3(trackPoints, true);
  const tubeSegments = 300;
  const pts = curve.getPoints(tubeSegments);

  // Build road quads
  const roadGeo = new THREE.BufferGeometry();
  const verts = [], uvs = [], normals = [], indices = [];

  for (let i = 0; i <= tubeSegments; i++) {
    const cur = pts[i];
    const next = pts[(i + 1) % pts.length];
    const tangent = new THREE.Vector3().subVectors(next, cur).normalize();
    const right = new THREE.Vector3(-tangent.z, 0, tangent.x);

    const left3D = new THREE.Vector3().addVectors(cur, right.clone().multiplyScalar(-roadWidth/2));
    const right3D = new THREE.Vector3().addVectors(cur, right.clone().multiplyScalar(roadWidth/2));

    verts.push(left3D.x, 0.02, left3D.z, right3D.x, 0.02, right3D.z);
    uvs.push(0, i/tubeSegments, 1, i/tubeSegments);
    normals.push(0,1,0, 0,1,0);
  }
  for (let i = 0; i < tubeSegments; i++) {
    const a = i*2, b=i*2+1, c=i*2+2, d=i*2+3;
    indices.push(a,b,c, b,d,c);
  }
  roadGeo.setAttribute('position', new THREE.BufferAttribute(new Float32Array(verts), 3));
  roadGeo.setAttribute('uv', new THREE.BufferAttribute(new Float32Array(uvs), 2));
  roadGeo.setAttribute('normal', new THREE.BufferAttribute(new Float32Array(normals), 3));
  roadGeo.setIndex(indices);

  const roadMat = new THREE.MeshStandardMaterial({
    color: isDesert ? 0x3a3028 : 0x1a1e28,
    roughness: 0.9, metalness: 0.05
  });
  trackMesh = new THREE.Mesh(roadGeo, roadMat);
  trackMesh.receiveShadow = true;
  scene.add(trackMesh);

  // Road markings (center line dashes)
  for (let i = 0; i < tubeSegments; i += 6) {
    const cur = pts[i];
    const next = pts[i+1] || pts[0];
    const lineGeo = new THREE.PlaneGeometry(0.3, 4);
    const lineMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.8 });
    const line = new THREE.Mesh(lineGeo, lineMat);
    line.position.set(cur.x, 0.03, cur.z);
    line.rotation.x = -Math.PI/2;
    const angle = Math.atan2(next.z - cur.z, next.x - cur.x);
    line.rotation.z = -angle;
    scene.add(line);
  }

  // Edge barriers / curbs
  for (let i = 0; i < pts.length - 1; i++) {
    const cur = pts[i];
    const next = pts[i+1];
    const tangent = new THREE.Vector3().subVectors(next, cur).normalize();
    const right = new THREE.Vector3(-tangent.z, 0, tangent.x);

    [-1, 1].forEach(side => {
      const edgePt = cur.clone().addScaledVector(right, side * (roadWidth/2 + 0.8));
      const curbGeo = new THREE.BoxGeometry(1.5, 0.25, 1.5);
      const curbMat = new THREE.MeshStandardMaterial({
        color: i % 4 < 2 ? 0xff2222 : 0xffffff,
        roughness: 0.7
      });
      const curb = new THREE.Mesh(curbGeo, curbMat);
      curb.position.set(edgePt.x, 0.12, edgePt.z);
      curb.receiveShadow = true;
      scene.add(curb);
    });
  }

  // Armco barriers
  for (let i = 0; i < pts.length - 1; i += 3) {
    const cur = pts[i];
    const next = pts[(i+3) % pts.length];
    const tangent = new THREE.Vector3().subVectors(next, cur).normalize();
    const right = new THREE.Vector3(-tangent.z, 0, tangent.x);
    const len = cur.distanceTo(next) * 3;

    [-1, 1].forEach(side => {
      const barrier = new THREE.Mesh(
        new THREE.BoxGeometry(len, 0.8, 0.25),
        new THREE.MeshStandardMaterial({ color: 0xaaaaaa, roughness: 0.6, metalness: 0.4 })
      );
      const pos = cur.clone().addScaledVector(right, side * (roadWidth/2 + 2.2));
      barrier.position.set(pos.x, 0.4, pos.z);
      const angle = Math.atan2(tangent.z, tangent.x);
      barrier.rotation.y = -angle;
      barrier.castShadow = true; barrier.receiveShadow = true;
      scene.add(barrier);
    });
  }

  // Start/Finish line
  const sfGeo = new THREE.PlaneGeometry(roadWidth, 2);
  const sfMat = new THREE.MeshStandardMaterial({ color: 0xffffff });
  const sfLine = new THREE.Mesh(sfGeo, sfMat);
  sfLine.position.set(trackPoints[0].x, 0.03, trackPoints[0].z);
  sfLine.rotation.x = -Math.PI/2;
  scene.add(sfLine);

  // Grandstands / Environment objects
  buildEnvironment(trackId, pts);
}

function buildEnvironment(trackId, pts) {
  const isNight = trackId === 'night';
  const isDesert = trackId === 'desert';

  if (!isDesert) {
    // Grandstands every ~50 pts
    for (let i = 0; i < pts.length; i += 30) {
      const cur = pts[i];
      const next = pts[(i+1)%pts.length];
      const tangent = new THREE.Vector3().subVectors(next, cur).normalize();
      const right = new THREE.Vector3(-tangent.z, 0, tangent.x);

      const standSide = (Math.random() > 0.5 ? 1 : -1);
      const standPos = cur.clone().addScaledVector(right, standSide * 30);
      const standGeo = new THREE.BoxGeometry(20, 8 + Math.random()*4, 6);
      const standMat = new THREE.MeshStandardMaterial({ color: 0x445566, roughness: 0.8 });
      const stand = new THREE.Mesh(standGeo, standMat);
      stand.position.set(standPos.x, 4, standPos.z);
      stand.castShadow = true;
      scene.add(stand);

      // Crowd dots on top
      for (let r = 0; r < 20; r++) {
        const dotGeo = new THREE.SphereGeometry(0.3, 4, 3);
        const colors = [0xff4444, 0x4444ff, 0x44ff44, 0xffff44, 0xff44ff];
        const dotMat = new THREE.MeshStandardMaterial({ color: colors[Math.floor(Math.random()*colors.length)] });
        const dot = new THREE.Mesh(dotGeo, dotMat);
        dot.position.set(standPos.x + (Math.random()-0.5)*18, 8 + Math.random()*4 + Math.random()*2, standPos.z + (Math.random()-0.5)*4);
        scene.add(dot);
      }
    }

    // Trees around track
    for (let i = 0; i < 80; i++) {
      const angle = Math.random() * Math.PI * 2;
      const r = 220 + Math.random() * 200;
      const x = Math.cos(angle) * r;
      const z = Math.sin(angle) * r * 0.7;
      const h = 5 + Math.random() * 8;
      // Trunk
      const trunk = new THREE.Mesh(
        new THREE.CylinderGeometry(0.3, 0.5, h, 6),
        new THREE.MeshStandardMaterial({ color: 0x4a2e10, roughness: 0.9 })
      );
      trunk.position.set(x, h/2, z);
      trunk.castShadow = true;
      scene.add(trunk);
      // Canopy
      const canopy = new THREE.Mesh(
        new THREE.SphereGeometry(3 + Math.random()*2, 7, 5),
        new THREE.MeshStandardMaterial({ color: isNight ? 0x113322 : 0x2d7a20, roughness: 0.95 })
      );
      canopy.position.set(x, h + 2, z);
      canopy.castShadow = true;
      scene.add(canopy);
    }
  } else {
    // Desert rocks
    for (let i = 0; i < 60; i++) {
      const angle = Math.random() * Math.PI * 2;
      const r = 200 + Math.random() * 250;
      const x = Math.cos(angle) * r, z = Math.sin(angle) * r * 0.7;
      const s = 2 + Math.random() * 8;
      const rock = new THREE.Mesh(
        new THREE.DodecahedronGeometry(s, 0),
        new THREE.MeshStandardMaterial({ color: 0x886633, roughness: 0.95 })
      );
      rock.position.set(x, s*0.4, z);
      rock.rotation.set(Math.random(), Math.random(), Math.random());
      rock.castShadow = true;
      scene.add(rock);
    }
    // Cacti
    for (let i = 0; i < 30; i++) {
      const angle = Math.random() * Math.PI * 2;
      const r = 180 + Math.random() * 300;
      const x = Math.cos(angle) * r, z = Math.sin(angle) * r * 0.7;
      const trunk = new THREE.Mesh(
        new THREE.CylinderGeometry(0.4, 0.5, 6, 8),
        new THREE.MeshStandardMaterial({ color: 0x3a7a20, roughness: 0.9 })
      );
      trunk.position.set(x, 3, z);
      scene.add(trunk);
    }
  }

  // Tire stacks at corners
  for (let i = 0; i < pts.length; i += 15) {
    const cur = pts[i];
    const next = pts[(i+1)%pts.length];
    const tangent = new THREE.Vector3().subVectors(next, cur).normalize();
    const right = new THREE.Vector3(-tangent.z, 0, tangent.x);
    [-1,1].forEach(side => {
      const pos = cur.clone().addScaledVector(right, side * (18/2 + 4));
      const tireGeo = new THREE.TorusGeometry(0.8, 0.3, 8, 12);
      const tireMat = new THREE.MeshStandardMaterial({ color: 0x111111, roughness: 0.95 });
      for (let s = 0; s < 3; s++) {
        const tire = new THREE.Mesh(tireGeo, tireMat);
        tire.position.set(pos.x, 0.8 + s*0.6, pos.z);
        tire.rotation.x = Math.PI/2;
        tire.castShadow = true;
        scene.add(tire);
      }
    });
  }
}

// ======================= PHOTOREALISTIC CAR MODEL =======================
function createCarMesh(carDef, isPlayer) {
  const group = new THREE.Group();
  const color = carDef.color;
  const type = carDef.carType || 'sport';

  // ---- PAINT MATERIAL (photorealistic) ----
  const paintMat = new THREE.MeshStandardMaterial({
    color,
    roughness: 0.08,
    metalness: 0.92,
    envMapIntensity: 2.5,
  });
  const carbonMat = new THREE.MeshStandardMaterial({ color:0x111111, roughness:0.4, metalness:0.6 });
  const chromeMat = new THREE.MeshStandardMaterial({ color:0xdddddd, roughness:0.05, metalness:1.0 });
  const glassMat  = new THREE.MeshStandardMaterial({ color:0x223344, roughness:0.0, metalness:0.1, transparent:true, opacity:0.35 });
  const blackMat  = new THREE.MeshStandardMaterial({ color:0x080808, roughness:0.8, metalness:0.1 });
  const redBrakeMat = new THREE.MeshStandardMaterial({ color:0xcc0000, roughness:0.4, metalness:0.6 });
  const tireMat   = new THREE.MeshStandardMaterial({ color:0x0a0a0a, roughness:1.0, metalness:0.0 });
  const rimMat    = new THREE.MeshStandardMaterial({ color:0xcccccc, roughness:0.1, metalness:1.0 });
  const lightMat  = new THREE.MeshStandardMaterial({ color:0xffffff, emissive:0xffffaa, emissiveIntensity: isPlayer?3:1.5, roughness:0.0 });
  const tailMat   = new THREE.MeshStandardMaterial({ color:0xff0000, emissive:0xff0000, emissiveIntensity:2.0, roughness:0.1 });
  const interiorMat = new THREE.MeshStandardMaterial({ color:0x1a1008, roughness:0.9, metalness:0.1 });
  const seatMat   = new THREE.MeshStandardMaterial({ color:0x220000, roughness:0.8, metalness:0.05 });

  // ---- CAR DIMENSIONS by type ----
  const dims = {
    ferrari: { L:4.7, W:2.05, H:1.16, wheelbase:2.65, wheelR:0.36, roofH:0.38, roofZ:-0.05 },
    lambo:   { L:4.9, W:2.10, H:1.13, wheelbase:2.70, wheelR:0.38, roofH:0.34, roofZ:-0.1  },
    bugatti: { L:4.5, W:2.00, H:1.10, wheelbase:2.72, wheelR:0.37, roofH:0.30, roofZ:-0.05 },
    sport:   { L:4.6, W:1.95, H:1.20, wheelbase:2.68, wheelR:0.35, roofH:0.40, roofZ: 0.0  },
    muscle:  { L:4.8, W:1.98, H:1.30, wheelbase:2.72, wheelR:0.37, roofH:0.42, roofZ: 0.05 },
    sedan:   { L:4.5, W:1.80, H:1.35, wheelbase:2.60, wheelR:0.33, roofH:0.50, roofZ: 0.08 },
  }[type] || { L:4.6, W:1.95, H:1.20, wheelbase:2.68, wheelR:0.35, roofH:0.40, roofZ:0.0 };

  const { L, W, H, wheelR, roofH, roofZ } = dims;
  const halfL = L/2, halfW = W/2;

  // ---- MAIN BODY using LatheGeometry cross-section approach ----
  // We build the body as multiple layered panels for realism

  // Lower body sill (rocker panel)
  const rockerGeo = new THREE.BoxGeometry(W + 0.04, 0.22, L - 0.6);
  const rocker = new THREE.Mesh(rockerGeo, paintMat);
  rocker.position.y = wheelR - 0.05;
  rocker.castShadow = true;
  group.add(rocker);

  // Main body shell - using a shaped geometry
  // We approximate the curved body with multiple box panels at angles
  function addBodyPanel(px, py, pz, bw, bh, bl, rx, ry, rz, mat) {
    const geo = new THREE.BoxGeometry(bw, bh, bl);
    const mesh = new THREE.Mesh(geo, mat || paintMat);
    mesh.position.set(px, py, pz);
    mesh.rotation.set(rx||0, ry||0, rz||0);
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    group.add(mesh);
    return mesh;
  }

  // Floor/underbody
  const floorGeo = new THREE.BoxGeometry(W - 0.4, 0.06, L - 0.3);
  const floor = new THREE.Mesh(floorGeo, blackMat);
  floor.position.y = 0.06;
  group.add(floor);

  // Lower body (widest part, near wheel arches)
  const lowerBodyGeo = new THREE.BoxGeometry(W, H * 0.42, L - 0.4);
  const lowerBody = new THREE.Mesh(lowerBodyGeo, paintMat);
  lowerBody.position.y = wheelR + 0.18;
  lowerBody.castShadow = true;
  group.add(lowerBody);

  // Mid body taper
  const midBodyGeo = new THREE.BoxGeometry(W - 0.06, H * 0.22, L - 0.2);
  const midBody = new THREE.Mesh(midBodyGeo, paintMat);
  midBody.position.y = wheelR + 0.52;
  midBody.castShadow = true;
  group.add(midBody);

  // Hood (sloped front)
  const hoodGeo = new THREE.BoxGeometry(W - 0.08, 0.06, L * 0.32);
  const hood = new THREE.Mesh(hoodGeo, paintMat);
  hood.position.set(0, wheelR + 0.60, halfL * 0.55);
  hood.rotation.x = type==='lambo' ? 0.14 : type==='ferrari' ? 0.10 : 0.07;
  hood.castShadow = true;
  group.add(hood);

  // Hood slope front edge
  const hoodFrontGeo = new THREE.BoxGeometry(W - 0.08, H * 0.28, L * 0.14);
  const hoodFront = new THREE.Mesh(hoodFrontGeo, paintMat);
  hoodFront.position.set(0, wheelR + 0.38, halfL * 0.83);
  hoodFront.rotation.x = type==='lambo' ? 0.30 : 0.18;
  hoodFront.castShadow = true;
  group.add(hoodFront);

  // Trunk/rear deck
  const trunkGeo = new THREE.BoxGeometry(W - 0.10, 0.06, L * 0.22);
  const trunk = new THREE.Mesh(trunkGeo, paintMat);
  trunk.position.set(0, wheelR + 0.62, -halfL * 0.55);
  trunk.rotation.x = type==='lambo' || type==='ferrari' ? -0.05 : -0.04;
  trunk.castShadow = true;
  group.add(trunk);

  // Rear slope
  const rearSlopeGeo = new THREE.BoxGeometry(W - 0.10, H * 0.32, L * 0.12);
  const rearSlope = new THREE.Mesh(rearSlopeGeo, paintMat);
  rearSlope.position.set(0, wheelR + 0.36, -halfL * 0.84);
  rearSlope.rotation.x = type==='ferrari'||type==='lambo' ? -0.5 : -0.3;
  rearSlope.castShadow = true;
  group.add(rearSlope);

  // ---- ROOF / GREENHOUSE ----
  const roofY = wheelR + H * 0.72;
  const roofGeo = new THREE.BoxGeometry(W - 0.24, roofH * 0.15, L * 0.34 + roofZ);
  const roofMesh = new THREE.Mesh(roofGeo, paintMat);
  roofMesh.position.set(0, roofY, roofZ * 0.5);
  roofMesh.castShadow = true;
  group.add(roofMesh);

  // A-pillars (front glass frame)
  [[halfW*0.55, roofY - 0.06, halfL*0.38], [-halfW*0.55, roofY - 0.06, halfL*0.38]].forEach(([px,py,pz]) => {
    const aGeo = new THREE.BoxGeometry(0.045, roofH * 0.85, 0.045);
    const a = new THREE.Mesh(aGeo, carbonMat);
    a.position.set(px, py, pz);
    a.rotation.x = -0.55;
    a.castShadow = true;
    group.add(a);
  });

  // Windshield
  const windshieldGeo = new THREE.BoxGeometry(W - 0.35, roofH * 0.72, 0.04);
  const windshield = new THREE.Mesh(windshieldGeo, glassMat);
  windshield.position.set(0, roofY - 0.06, halfL*0.36);
  windshield.rotation.x = type==='lambo' ? -0.7 : type==='ferrari' ? -0.65 : -0.58;
  group.add(windshield);

  // Rear window
  const rearWindGeo = new THREE.BoxGeometry(W - 0.40, roofH * 0.60, 0.04);
  const rearWind = new THREE.Mesh(rearWindGeo, glassMat);
  rearWind.position.set(0, roofY - 0.12, -halfL*0.32);
  rearWind.rotation.x = type==='lambo' ? 0.8 : 0.65;
  group.add(rearWind);

  // Side windows (L and R)
  [-1, 1].forEach(side => {
    const sideWinGeo = new THREE.BoxGeometry(0.025, roofH * 0.65, L * 0.30);
    const sideWin = new THREE.Mesh(sideWinGeo, glassMat);
    sideWin.position.set(side * (halfW - 0.05), roofY - 0.1, roofZ * 0.3);
    group.add(sideWin);
  });

  // ---- FRONT FASCIA ----
  // Front bumper
  const frontBumperGeo = new THREE.BoxGeometry(W, H * 0.26, 0.14);
  const frontBumper = new THREE.Mesh(frontBumperGeo, type==='bugatti'||type==='ferrari' ? carbonMat : paintMat);
  frontBumper.position.set(0, wheelR + 0.12, halfL - 0.07);
  frontBumper.castShadow = true;
  group.add(frontBumper);

  // Front grille opening
  const grilleGeo = new THREE.BoxGeometry(W * 0.52, H * 0.14, 0.08);
  const grilleMat = new THREE.MeshStandardMaterial({ color:0x050505, roughness:0.9 });
  const grille = new THREE.Mesh(grilleGeo, grilleMat);
  grille.position.set(0, wheelR + 0.16, halfL + 0.01);
  group.add(grille);

  // Grille mesh bars
  for (let g = 0; g < 5; g++) {
    const bar = new THREE.Mesh(new THREE.BoxGeometry(W*0.48, 0.02, 0.04), chromeMat);
    bar.position.set(0, wheelR + 0.10 + g * 0.04, halfL + 0.02);
    group.add(bar);
  }

  // Front splitter (supercars)
  if (type !== 'sedan' && type !== 'muscle') {
    const splitterGeo = new THREE.BoxGeometry(W + 0.2, 0.03, 0.25);
    const splitter = new THREE.Mesh(splitterGeo, carbonMat);
    splitter.position.set(0, wheelR - 0.04, halfL + 0.05);
    splitter.castShadow = true;
    group.add(splitter);
    // Splitter fins
    for (let f = -2; f <= 2; f++) {
      const fin = new THREE.Mesh(new THREE.BoxGeometry(0.025, 0.07, 0.20), carbonMat);
      fin.position.set(f * (W/5), wheelR + 0.01, halfL + 0.04);
      group.add(fin);
    }
  }

  // Headlights (realistic multi-element LED style)
  [-1, 1].forEach(side => {
    const hx = side * (halfW - 0.22);
    const hy = wheelR + 0.52;
    const hz = halfL - 0.08;

    // Outer housing
    const housingGeo = new THREE.BoxGeometry(0.42, 0.15, 0.10);
    const housing = new THREE.Mesh(housingGeo, blackMat);
    housing.position.set(hx, hy, hz);
    group.add(housing);

    // Main beam (bright)
    const beamGeo = new THREE.BoxGeometry(0.20, 0.07, 0.06);
    const beam = new THREE.Mesh(beamGeo, lightMat);
    beam.position.set(hx, hy, hz + 0.04);
    group.add(beam);

    // DRL strip
    const drlGeo = new THREE.BoxGeometry(0.38, 0.025, 0.04);
    const drlMat = new THREE.MeshStandardMaterial({ color:0xffffff, emissive:0xffffff, emissiveIntensity: isPlayer ? 4 : 2 });
    const drl = new THREE.Mesh(drlGeo, drlMat);
    drl.position.set(hx, hy + 0.06, hz + 0.04);
    group.add(drl);

    // Side marker
    const markerGeo = new THREE.BoxGeometry(0.04, 0.06, 0.05);
    const markerMat = new THREE.MeshStandardMaterial({ color:0xffaa00, emissive:0xffaa00, emissiveIntensity:1 });
    const marker = new THREE.Mesh(markerGeo, markerMat);
    marker.position.set(side * (halfW + 0.02), hy, hz - 0.1);
    group.add(marker);

    // Actual light cone (only player)
    if (isPlayer) {
      const spotlight = new THREE.SpotLight(0xfff5e0, 4, 80, 0.35, 0.4, 1.5);
      spotlight.position.set(hx, hy, hz);
      spotlight.target.position.set(hx * 0.3, -2, hz + 50);
      group.add(spotlight);
      group.add(spotlight.target);
    }
  });

  // ---- REAR FASCIA ----
  // Rear bumper
  const rearBumperGeo = new THREE.BoxGeometry(W, H * 0.28, 0.12);
  const rearBumper = new THREE.Mesh(rearBumperGeo, type==='ferrari'||type==='lambo'||type==='bugatti' ? carbonMat : paintMat);
  rearBumper.position.set(0, wheelR + 0.14, -halfL + 0.06);
  rearBumper.castShadow = true;
  group.add(rearBumper);

  // Taillights (LED bar style)
  const tailBarGeo = new THREE.BoxGeometry(W - 0.15, 0.055, 0.06);
  const tailBar = new THREE.Mesh(tailBarGeo, tailMat);
  tailBar.position.set(0, wheelR + 0.55, -halfL + 0.04);
  group.add(tailBar);

  // Individual tail light clusters
  [-1, 1].forEach(side => {
    const tlx = side * (halfW - 0.22);
    const tly = wheelR + 0.50;
    const tlz = -halfL + 0.06;
    const tlHousingGeo = new THREE.BoxGeometry(0.44, 0.20, 0.08);
    const tlHousing = new THREE.Mesh(tlHousingGeo, blackMat);
    tlHousing.position.set(tlx, tly, tlz);
    group.add(tlHousing);
    const tlGeo = new THREE.BoxGeometry(0.36, 0.12, 0.05);
    const tl = new THREE.Mesh(tlGeo, tailMat);
    tl.position.set(tlx, tly, tlz + 0.03);
    group.add(tl);
  });

  // Exhaust pipes
  const exhaustPositions = type==='bugatti' ? [[-0.35,-0.2],[0.35,-0.2],[-0.12,-0.2],[0.12,-0.2]] :
                           type==='lambo'   ? [[-0.3,-0.15],[0.3,-0.15]] :
                           type==='ferrari' ? [[-0.28,-0.12],[0.28,-0.12]] :
                           [[-0.2,-0.1],[0.2,-0.1]];
  exhaustPositions.forEach(([ex, ey]) => {
    // Exhaust tip
    const exGeo = new THREE.CylinderGeometry(0.055, 0.065, 0.14, 12);
    const exMesh = new THREE.Mesh(exGeo, chromeMat);
    exMesh.rotation.x = Math.PI/2;
    exMesh.position.set(ex, wheelR + 0.12 + ey, -halfL + 0.02);
    group.add(exMesh);
    // Inner dark
    const exInner = new THREE.Mesh(new THREE.CircleGeometry(0.04, 12), blackMat);
    exInner.position.set(ex, wheelR + 0.12 + ey, -halfL - 0.01);
    exInner.rotation.x = Math.PI/2;
    group.add(exInner);
  });

  // Exhaust glow point light
  const exhaustLight = new THREE.PointLight(0xff6600, 0, 4);
  exhaustLight.position.set(0, wheelR + 0.1, -halfL);
  group.add(exhaustLight);
  group.exhaustLight = exhaustLight;

  // ---- DIFFUSER (supercars) ----
  if (type === 'ferrari' || type === 'lambo' || type === 'bugatti') {
    const diffGeo = new THREE.BoxGeometry(W - 0.2, 0.08, 0.45);
    const diff = new THREE.Mesh(diffGeo, carbonMat);
    diff.position.set(0, wheelR - 0.04, -halfL + 0.22);
    diff.rotation.x = 0.3;
    group.add(diff);
    for (let d = -3; d <= 3; d++) {
      const vane = new THREE.Mesh(new THREE.BoxGeometry(0.02, 0.09, 0.40), carbonMat);
      vane.position.set(d * ((W-0.4)/7), wheelR - 0.04, -halfL + 0.22);
      vane.rotation.x = 0.3;
      group.add(vane);
    }
  }

  // ---- REAR WING / SPOILER ----
  if (type === 'bugatti') {
    // Active wing - large
    const wingGeo = new THREE.BoxGeometry(W + 0.5, 0.055, 0.55);
    const wingMat2 = new THREE.MeshStandardMaterial({ color:0x111111, roughness:0.3, metalness:0.8 });
    const wing = new THREE.Mesh(wingGeo, wingMat2);
    wing.position.set(0, wheelR + H * 0.72, -halfL + 0.18);
    group.add(wing);
    // Wing endplates
    [-1,1].forEach(side => {
      const ep = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.35, 0.60), carbonMat);
      ep.position.set(side*(halfW+0.27), wheelR + H*0.65, -halfL+0.18);
      group.add(ep);
    });
    // Wing mounts
    [-0.5,0.5].forEach(mx => {
      const mount = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.28, 0.04), chromeMat);
      mount.position.set(mx, wheelR + H*0.58, -halfL+0.18);
      group.add(mount);
    });
  } else if (type === 'lambo' || type === 'ferrari') {
    const wingGeo = new THREE.BoxGeometry(W + 0.15, 0.045, 0.42);
    const wing = new THREE.Mesh(wingGeo, carbonMat);
    wing.position.set(0, wheelR + H*0.68, -halfL+0.22);
    group.add(wing);
    [-0.4,0.4].forEach(mx => {
      const mount = new THREE.Mesh(new THREE.BoxGeometry(0.035, 0.22, 0.035), carbonMat);
      mount.position.set(mx, wheelR + H*0.57, -halfL+0.22);
      group.add(mount);
    });
  } else if (type === 'sport' || type === 'muscle') {
    const spoilerGeo = new THREE.BoxGeometry(W + 0.1, 0.055, 0.30);
    const spoiler = new THREE.Mesh(spoilerGeo, paintMat);
    spoiler.position.set(0, wheelR + H*0.58, -halfL+0.20);
    group.add(spoiler);
  }

  // ---- SIDE SKIRTS ----
  [-1,1].forEach(side => {
    const skirtGeo = new THREE.BoxGeometry(0.065, 0.14, L - 0.85);
    const skirt = new THREE.Mesh(skirtGeo, carbonMat);
    skirt.position.set(side*(halfW+0.025), wheelR + 0.07, 0);
    group.add(skirt);
  });

  // ---- DOOR HANDLES ----
  [-1,1].forEach(side => {
    const handle = new THREE.Mesh(new THREE.BoxGeometry(0.025, 0.04, 0.14), chromeMat);
    handle.position.set(side*(halfW+0.03), wheelR+0.60, 0.1);
    group.add(handle);
  });

  // ---- INTERIOR (visible through glass) ----
  // Dashboard
  const dashGeo = new THREE.BoxGeometry(W - 0.5, 0.14, 0.55);
  const dash = new THREE.Mesh(dashGeo, carbonMat);
  dash.position.set(0, wheelR+0.72, halfL*0.32);
  group.add(dash);
  // Steering wheel
  const swGeo = new THREE.TorusGeometry(0.17, 0.025, 8, 20);
  const sw = new THREE.Mesh(swGeo, blackMat);
  sw.position.set(isPlayer ? -0.24 : 0.24, wheelR+0.78, halfL*0.28);
  sw.rotation.x = -0.35;
  group.add(sw);
  // Seats (2 front buckets)
  [-1,1].forEach(side => {
    // Seat base
    const seatBase = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.09, 0.50), seatMat);
    seatBase.position.set(side*0.36, wheelR+0.52, 0.06);
    group.add(seatBase);
    // Seat back
    const seatBack = new THREE.Mesh(new THREE.BoxGeometry(0.52, 0.50, 0.07), seatMat);
    seatBack.position.set(side*0.36, wheelR+0.78, -0.18);
    seatBack.rotation.x = 0.05;
    group.add(seatBack);
    // Head rest
    const headRest = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.18, 0.08), seatMat);
    headRest.position.set(side*0.36, wheelR+1.02, -0.20);
    group.add(headRest);
  });
  // Center console
  const consoleGeo = new THREE.BoxGeometry(0.24, 0.18, 0.60);
  const consoleMesh = new THREE.Mesh(consoleGeo, carbonMat);
  consoleMesh.position.set(0, wheelR+0.60, 0.02);
  group.add(consoleMesh);

  // ---- WHEEL ARCHES ----
  [-1,1].forEach(side => {
    [halfL*0.53, -halfL*0.46].forEach(wz => {
      const archGeo = new THREE.CylinderGeometry(wheelR+0.09, wheelR+0.09, 0.08, 24, 1, false, 0, Math.PI);
      const arch = new THREE.Mesh(archGeo, paintMat);
      arch.position.set(side*(halfW), wheelR, wz);
      arch.rotation.z = side > 0 ? -Math.PI/2 : Math.PI/2;
      arch.rotation.y = side > 0 ? 0 : Math.PI;
      group.add(arch);
    });
  });

  // ---- WHEELS (4 fully detailed) ----
  group.wheels = [];
  const wheelPositions = [
    [halfW*0.88, wheelR, halfL*0.53, true,  true ],  // FR
    [-halfW*0.88, wheelR, halfL*0.53, true, false],  // FL
    [halfW*0.88, wheelR, -halfL*0.46, false, true],  // RR
    [-halfW*0.88, wheelR, -halfL*0.46, false, false] // RL
  ];

  wheelPositions.forEach(([wx, wy, wz, isFront, isRight]) => {
    const wheelGroup = new THREE.Group();

    // Tire (low-profile)
    const tireGeo = new THREE.CylinderGeometry(wheelR, wheelR, 0.28, 28);
    const tireMesh = new THREE.Mesh(tireGeo, tireMat);
    tireMesh.rotation.z = Math.PI/2;
    tireMesh.castShadow = true;
    wheelGroup.add(tireMesh);

    // Tire sidewall detail (tread ring)
    const treadGeo = new THREE.TorusGeometry(wheelR - 0.01, 0.035, 8, 28);
    const tread = new THREE.Mesh(treadGeo, new THREE.MeshStandardMaterial({color:0x151515, roughness:0.95}));
    tread.rotation.y = Math.PI/2;
    tread.position.x = isRight ? 0.13 : -0.13;
    wheelGroup.add(tread);

    // Rim outer face
    const rimFaceGeo = new THREE.CylinderGeometry(wheelR - 0.035, wheelR - 0.035, 0.03, 24);
    const rimFaceOuter = new THREE.Mesh(rimFaceGeo, rimMat);
    rimFaceOuter.rotation.z = Math.PI/2;
    rimFaceOuter.position.x = isRight ? 0.135 : -0.135;
    wheelGroup.add(rimFaceOuter);

    // Rim spokes (5-spoke design)
    const spokeCount = type === 'bugatti' ? 8 : type === 'lambo' || type === 'ferrari' ? 10 : 5;
    for (let s = 0; s < spokeCount; s++) {
      const spokeAngle = (s / spokeCount) * Math.PI * 2;
      const spokeGeo = new THREE.BoxGeometry(0.055, wheelR * 1.55, 0.035);
      const spoke = new THREE.Mesh(spokeGeo, rimMat);
      spoke.position.x = isRight ? 0.12 : -0.12;
      spoke.rotation.x = spokeAngle;
      spoke.position.y = Math.sin(spokeAngle) * (wheelR*0.38);
      spoke.position.z = Math.cos(spokeAngle) * (wheelR*0.38);
      wheelGroup.add(spoke);
    }

    // Center cap
    const capGeo = new THREE.CylinderGeometry(0.075, 0.075, 0.04, 12);
    const cap = new THREE.Mesh(capGeo, chromeMat);
    cap.rotation.z = Math.PI/2;
    cap.position.x = isRight ? 0.14 : -0.14;
    wheelGroup.add(cap);

    // Brake rotor (slotted disc)
    const rotorGeo = new THREE.CylinderGeometry(wheelR - 0.10, wheelR - 0.10, 0.025, 24);
    const rotorMat = new THREE.MeshStandardMaterial({ color:0x666666, roughness:0.5, metalness:0.8 });
    const rotor = new THREE.Mesh(rotorGeo, rotorMat);
    rotor.rotation.z = Math.PI/2;
    rotor.position.x = isRight ? 0.07 : -0.07;
    wheelGroup.add(rotor);
    // Rotor slots
    for (let rs = 0; rs < 12; rs++) {
      const slotAngle = (rs/12)*Math.PI*2;
      const slot = new THREE.Mesh(new THREE.BoxGeometry(0.03, wheelR*1.2, 0.006), blackMat);
      slot.position.x = isRight ? 0.07 : -0.07;
      slot.rotation.x = slotAngle;
      slot.position.y = Math.sin(slotAngle)*(wheelR*0.52);
      slot.position.z = Math.cos(slotAngle)*(wheelR*0.52);
      wheelGroup.add(slot);
    }

    // Brake caliper
    const caliperGeo = new THREE.BoxGeometry(0.07, 0.16, 0.20);
    const caliper = new THREE.Mesh(caliperGeo, redBrakeMat);
    caliper.position.x = isRight ? 0.06 : -0.06;
    caliper.position.y = -(wheelR * 0.62);
    wheelGroup.add(caliper);
    // Caliper "Brembo" lettering approximation
    const caliperTop = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.04, 0.12), new THREE.MeshStandardMaterial({color:0xffffff, roughness:0.8}));
    caliperTop.position.copy(caliper.position);
    caliperTop.position.x += isRight ? 0.02 : -0.02;
    wheelGroup.add(caliperTop);

    wheelGroup.position.set(wx, wy, wz);
    group.add(wheelGroup);
    group.wheels.push({ mesh: wheelGroup, isFront });
  });

  // ---- UNDERBODY FLAT SHADOW ----
  const shadowGeo = new THREE.PlaneGeometry(W * 0.92, L * 0.85);
  const shadowMat = new THREE.MeshBasicMaterial({ color:0x000000, transparent:true, opacity:0.45, depthWrite:false });
  const shadowMesh = new THREE.Mesh(shadowGeo, shadowMat);
  shadowMesh.rotation.x = -Math.PI/2;
  shadowMesh.position.y = 0.01;
  group.add(shadowMesh);

  // ---- NUMBERPLATE ----
  const plateGeo = new THREE.BoxGeometry(0.52, 0.12, 0.025);
  const plateMat = new THREE.MeshStandardMaterial({ color:0xffffee, roughness:0.8 });
  const plateFront = new THREE.Mesh(plateGeo, plateMat);
  plateFront.position.set(0, wheelR+0.24, halfL+0.05);
  group.add(plateFront);
  const plateRear = new THREE.Mesh(plateGeo, plateMat);
  plateRear.position.set(0, wheelR+0.22, -halfL-0.04);
  group.add(plateRear);

  return group;
}

// ======================= PHYSICS STATE =======================
let carPos, carVel, carAng, carAngVel;
let onGround = true;
let skidding = false;
let skidParticles = [];

function initCarPhysics() {
  carPos = new THREE.Vector3(trackPoints[0].x, 0.4, trackPoints[0].z + 5);
  carVel = new THREE.Vector3(0, 0, 0);
  carAng = 0;
  carAngVel = 0;
  wheelAngle = 0;
}

// ======================= SPAWN CARS =======================
function spawnCars() {
  const carDef = CAR_DEFS.find(c=>c.id===selectedCarId);
  playerCar = createCarMesh(carDef, true);
  scene.add(playerCar);
  initCarPhysics();

  // AI cars
  const aiCarDefs = CAR_DEFS.filter(c=>c.id!==selectedCarId).slice(0, 4);
  aiCarDefs.forEach((def, i) => {
    const mesh = createCarMesh(def, false);
    const startPt = trackPoints[(i+1)*3 % trackPoints.length];
    mesh.position.set(startPt.x, 0.4, startPt.z);
    scene.add(mesh);
    aiCars.push({
      mesh,
      def,
      progress: -(i+1) * 5,
      speed: 0,
      angle: 0,
      angVel: 0,
      targetProgress: 0,
      lapCount: 1,
      finished: false,
      pos: new THREE.Vector3(startPt.x, 0.4, startPt.z),
      vel: new THREE.Vector3()
    });
  });
}

// ======================= INPUT =======================
document.addEventListener('keydown', e => {
  keys[e.code] = true;
  if (e.code==='KeyC') camMode=(camMode+1)%3;
  if (e.code==='KeyR') resetCar();
  e.preventDefault();
}, false);
document.addEventListener('keyup', e => { keys[e.code] = false; }, false);

// ======================= GAMEPAD =======================
let gamepadIndex = -1;
let gamepadActive = false;
const gp = { throttle:0, brake:0, steerL:0, steerR:0, nitro:false, handbrake:false, camBtn:false };
let gpCamPressed = false;

window.addEventListener('gamepadconnected', e => {
  gamepadIndex = e.gamepad.index;
  gamepadActive = true;
  const ind = document.getElementById('gamepad-indicator');
  if (ind) { ind.style.display='block'; ind.textContent='🎮 CONTROLLER: ' + e.gamepad.id.substring(0,22); }
  console.log('Gamepad connected:', e.gamepad.id);
});
window.addEventListener('gamepaddisconnected', e => {
  if (e.gamepad.index === gamepadIndex) {
    gamepadIndex = -1; gamepadActive = false;
    const ind = document.getElementById('gamepad-indicator');
    if (ind) ind.style.display='none';
  }
});

function pollGamepad() {
  if (gamepadIndex < 0) return;
  const pads = navigator.getGamepads ? navigator.getGamepads() : [];
  const pad = pads[gamepadIndex];
  if (!pad) return;

  // Standard mapping:
  // Axes: 0=Left X, 1=Left Y, 2=Right X, 3=Right Y
  // Buttons: 0=A/Cross, 1=B/Circle, 2=X/Square, 3=Y/Triangle
  //          4=LB, 5=RB, 6=LT (analog), 7=RT (analog)
  //          8=Select/Share, 9=Start/Options, 12=DPad Up, 13=DPad Down, 14=DPad Left, 15=DPad Right

  const leftX   = pad.axes[0] || 0;     // steer
  const rt      = pad.buttons[7] ? pad.buttons[7].value : 0; // throttle (RT)
  const lt      = pad.buttons[6] ? pad.buttons[6].value : 0; // brake (LT)
  const aBtn    = pad.buttons[0] ? pad.buttons[0].pressed : false; // A = gas fallback
  const bBtn    = pad.buttons[1] ? pad.buttons[1].pressed : false; // B = brake fallback
  const xBtn    = pad.buttons[2] ? pad.buttons[2].pressed : false; // X = handbrake
  const lbBtn   = pad.buttons[4] ? pad.buttons[4].pressed : false; // LB = nitro
  const rbBtn   = pad.buttons[5] ? pad.buttons[5].pressed : false; // RB = nitro alt
  const startBtn= pad.buttons[9] ? pad.buttons[9].pressed : false;
  const yBtn    = pad.buttons[3] ? pad.buttons[3].pressed : false; // Y = camera

  gp.throttle  = Math.max(rt, aBtn ? 1 : 0);
  gp.brake     = Math.max(lt, bBtn ? 1 : 0);
  gp.steerL    = leftX < -0.1 ? Math.abs(leftX) : 0;
  gp.steerR    = leftX >  0.1 ? leftX : 0;
  gp.nitro     = lbBtn || rbBtn;
  gp.handbrake = xBtn;

  if (yBtn && !gpCamPressed) { camMode=(camMode+1)%3; gpCamPressed=true; }
  if (!yBtn) gpCamPressed = false;
  if (startBtn) resetCar();
}

// ======================= GYRO / TILT STEERING =======================
let tiltEnabled = false;
let tiltBaseline = 0;
let tiltCalibrated = false;
let tiltValue = 0; // -1 to 1

function toggleTilt() {
  tiltEnabled = !tiltEnabled;
  tiltCalibrated = false;
  const btn = document.getElementById('btn-tilt-toggle');
  const lbl = document.getElementById('tilt-label');
  if (tiltEnabled) {
    btn && (btn.style.color = '#ffcc00');
    btn && (btn.style.borderColor = 'rgba(255,200,0,0.5)');
    lbl && (lbl.style.display = 'block');
    // Request permission on iOS 13+
    if (typeof DeviceOrientationEvent !== 'undefined' && typeof DeviceOrientationEvent.requestPermission === 'function') {
      DeviceOrientationEvent.requestPermission().then(state => {
        if (state !== 'granted') { tiltEnabled = false; alert('Tilt permission denied'); }
      }).catch(() => { tiltEnabled = false; });
    }
  } else {
    btn && (btn.style.color = '');
    btn && (btn.style.borderColor = '');
    lbl && (lbl.style.display = 'none');
    tiltValue = 0;
  }
}

window.addEventListener('deviceorientation', e => {
  if (!tiltEnabled) return;
  // gamma = left/right tilt (-90 to 90)
  const gamma = e.gamma || 0;
  if (!tiltCalibrated) { tiltBaseline = gamma; tiltCalibrated = true; }
  const delta = gamma - tiltBaseline;
  tiltValue = Math.max(-1, Math.min(1, delta / 25)); // 25° = full lock
}, false);

// ======================= TOUCH JOYSTICK =======================
let joystickActive = false;
let joystickTouchId = null;
let joystickOriginX = 0, joystickOriginY = 0;
const JOYSTICK_RADIUS = 60;

function setupTouchControls() {
  const zone = document.getElementById('joystick-zone');
  const base = document.getElementById('joystick-base');
  const knob = document.getElementById('joystick-knob');
  if (!zone || !base || !knob) return;

  function joystickStart(cx, cy, id) {
    joystickActive = true;
    joystickTouchId = id;
    const rect = base.getBoundingClientRect();
    joystickOriginX = rect.left + rect.width / 2;
    joystickOriginY = rect.top + rect.height / 2;
    joystickMove(cx, cy);
  }
  function joystickMove(cx, cy) {
    let dx = cx - joystickOriginX;
    let dy = cy - joystickOriginY;
    const dist = Math.sqrt(dx*dx + dy*dy);
    if (dist > JOYSTICK_RADIUS) { dx = dx/dist*JOYSTICK_RADIUS; dy = dy/dist*JOYSTICK_RADIUS; }
    joystickDX = dx / JOYSTICK_RADIUS;
    joystickDY = dy / JOYSTICK_RADIUS;
    knob.style.transform = `translate(calc(-50% + ${dx}px), calc(-50% + ${dy}px))`;
  }
  function joystickEnd() {
    joystickActive = false; joystickTouchId = null;
    joystickDX = 0; joystickDY = 0;
    knob.style.transform = 'translate(-50%, -50%)';
  }

  zone.addEventListener('touchstart', e => { e.preventDefault(); const t=e.changedTouches[0]; joystickStart(t.clientX,t.clientY,t.identifier); }, { passive:false });
  zone.addEventListener('touchmove',  e => { e.preventDefault(); for (const t of e.changedTouches) { if (t.identifier===joystickTouchId) joystickMove(t.clientX,t.clientY); } }, { passive:false });
  zone.addEventListener('touchend',   e => { e.preventDefault(); joystickEnd(); }, { passive:false });
  zone.addEventListener('touchcancel',e => { e.preventDefault(); joystickEnd(); }, { passive:false });

  // Action buttons
  function setupTouchBtn(id, keyName) {
    const btn = document.getElementById(id);
    if (!btn) return;
    const on  = e => { e.preventDefault(); e.stopPropagation(); keys[keyName]=true;  btn.classList.add('pressed');    };
    const off = e => { e.preventDefault(); e.stopPropagation(); keys[keyName]=false; btn.classList.remove('pressed'); };
    btn.addEventListener('touchstart',  on,  { passive:false });
    btn.addEventListener('touchend',    off, { passive:false });
    btn.addEventListener('touchcancel', off, { passive:false });
  }
  setupTouchBtn('btn-gas',       'KeyW');
  setupTouchBtn('btn-brake',     'KeyS');
  setupTouchBtn('btn-nitro',     'ShiftLeft');
  setupTouchBtn('btn-handbrake', 'Space');

  // Prevent canvas scroll swallowing
  document.getElementById('c').addEventListener('touchstart', e => e.preventDefault(), { passive:false });
  document.getElementById('c').addEventListener('touchmove',  e => e.preventDefault(), { passive:false });
}

function isTouchDevice() {
  return navigator.maxTouchPoints > 0 || 'ontouchstart' in window;
}

function resetCar() {
  const nearest = getNearestTrackPoint(carPos);
  const npt = trackPoints[nearest];
  carPos.set(npt.x, 0.5, npt.z);
  carVel.set(0,0,0);
  const next = trackPoints[(nearest+1) % trackPoints.length];
  carAng = Math.atan2(next.x - npt.x, next.z - npt.z);
  carAngVel = 0;
}

// ======================= TRACK HELPER =======================
function getNearestTrackPoint(pos) {
  let nearest = 0, nearDist = Infinity;
  trackPoints.forEach((pt, i) => {
    const d = pos.distanceTo(pt);
    if (d < nearDist) { nearDist = d; nearest = i; }
  });
  return nearest;
}

function getTrackProgress(pos) {
  const nearest = getNearestTrackPoint(pos);
  return nearest / (trackPoints.length - 1);
}

// ======================= UPDATE PHYSICS =======================
function updatePlayerCar(dt) {
  const carDef = CAR_DEFS.find(c=>c.id===selectedCarId);
  const maxSpeed = carDef.topSpeed / 3.6; // to m/s
  const accelForce = carDef.accel;
  const handling = carDef.handling;

  // Poll gamepad every frame
  pollGamepad();

  const throttle = (keys['KeyW'] || keys['ArrowUp']) ? 1 : 0;
  const brake = (keys['KeyS'] || keys['ArrowDown']) ? 1 : 0;
  // Joystick: up/down = throttle/brake, left/right = steer
  const joyThrottle = joystickDY < -0.2 ? Math.min(1, (-joystickDY - 0.2) / 0.8) : 0;
  const joyBrake    = joystickDY >  0.2 ? Math.min(1, (joystickDY  - 0.2) / 0.8) : 0;

  // Tilt steer (overrides joystick X when tilt active)
  const tiltSteerL = tiltEnabled && tiltValue < -0.08 ? Math.min(1, -tiltValue) : 0;
  const tiltSteerR = tiltEnabled && tiltValue >  0.08 ? Math.min(1,  tiltValue) : 0;

  const effectiveThrottle = Math.max(throttle, joyThrottle, gp.throttle);
  const effectiveBrake    = Math.max(brake,    joyBrake,    gp.brake);
  const steerL = Math.max((keys['KeyA']||keys['ArrowLeft']) ? 1:0, tiltEnabled ? tiltSteerL : Math.max(0,-joystickDX), gp.steerL);
  const steerR = Math.max((keys['KeyD']||keys['ArrowRight'])? 1:0, tiltEnabled ? tiltSteerR : Math.max(0, joystickDX), gp.steerR);
  const handbrake = (keys['Space'] ? 1 : 0) || (gp.handbrake ? 1 : 0);
  const isNitro = ((keys['ShiftLeft']||keys['ShiftRight']) || gp.nitro) && nitro > 0;

  // Speed scalar
  let speedScalar = carVel.length();
  if (carVel.dot(new THREE.Vector3(Math.sin(carAng),0,Math.cos(carAng))) < 0) speedScalar *= -1;

  // Nitro
  if (isNitro) {
    nitro = Math.max(0, nitro - dt * 25);
    nitroCooldown = false;
  } else if (!nitroCooldown && nitro < 100) {
    nitro = Math.min(100, nitro + dt * 8);
  }

  const nitroMult = isNitro ? 1.6 : 1.0;

  // Acceleration
  const fwd = new THREE.Vector3(Math.sin(carAng), 0, Math.cos(carAng));
  if (effectiveThrottle) {
    const force = fwd.clone().multiplyScalar(accelForce * nitroMult * effectiveThrottle * dt);
    carVel.add(force);
  }
  if (effectiveBrake) {
    if (speedScalar > 0.5) {
      carVel.add(fwd.clone().multiplyScalar(-accelForce * 0.7 * effectiveBrake * dt));
    } else {
      carVel.add(fwd.clone().multiplyScalar(-accelForce * 0.5 * effectiveBrake * dt));
    }
  }

  // Drag & friction
  const drag = handbrake ? 0.3 : 0.02;
  carVel.multiplyScalar(Math.max(0, 1 - drag - dt * 2.5));

  // Speed limit
  const spd = carVel.length();
  if (spd > maxSpeed * nitroMult) carVel.multiplyScalar(maxSpeed * nitroMult / spd);

  // Steering - only when moving
  const steerAmt = (steerL - steerR);
  const steerStrength = handling * Math.min(1, spd / 5);
  carAngVel += steerAmt * steerStrength * (1 + spd * 0.02) * dt * 60;
  carAngVel *= handbrake ? 0.7 : 0.88;

  carAng += carAngVel * dt;
  wheelAngle = steerAmt * Math.PI / 6;

  // Lateral friction (keeps car on road, not sliding sideways too much)
  const right = new THREE.Vector3(Math.cos(carAng), 0, -Math.sin(carAng));
  const lateralVel = right.clone().multiplyScalar(carVel.dot(right));
  const frictionFactor = handbrake ? 0.6 : 0.15;
  carVel.sub(lateralVel.multiplyScalar(frictionFactor));

  // Move car
  carPos.add(carVel.clone().multiplyScalar(dt));
  carPos.y = 0.4; // keep on ground

  // Align car mesh
  playerCar.position.copy(carPos);
  playerCar.rotation.y = carAng;

  // Wheel spin and steer
  playerCar.wheels.forEach(w => {
    // Spin the whole wheel group around local X (after rotating to face sideways)
    w.mesh.children[0] && w.mesh.children[0].rotateX(spd * dt * 3.0);
    if (w.isFront) w.mesh.rotation.y = wheelAngle;
  });

  // Exhaust glow
  if (playerCar.exhaustLight) {
    const throttleOn = effectiveThrottle > 0.1;
    const nitroOn = (keys['ShiftLeft'] || keys['ShiftRight']) && nitro > 5;
    playerCar.exhaustLight.intensity = throttleOn ? (1.5 + Math.random() * 3.0) * (nitroOn ? 4 : 1) : Math.max(0, playerCar.exhaustLight.intensity * 0.85);
    playerCar.exhaustLight.color.setHex(nitroOn ? 0x4488ff : 0xff6600);
  }

  // Skid marks (simplified particle)
  skidding = handbrake && spd > 3;

  // Update HUD
  carSpeed = spd * 3.6; // to km/h
  rpmVal = Math.min(100, (spd / maxSpeed) * 100);
  gearVal = Math.max(1, Math.min(6, Math.ceil(rpmVal / 17)));

  document.getElementById('speedo-val').textContent = Math.round(carSpeed);
  document.getElementById('rpm-bar').style.width = rpmVal + '%';
  document.getElementById('gear-val').textContent = gearVal;
  document.getElementById('nitro-bar').style.width = nitro + '%';
}

// ======================= AI UPDATE =======================
function updateAICar(ai, dt) {
  const nearest = getNearestTrackPoint(ai.pos);
  const lookahead = 5;
  const target = trackPoints[(nearest + lookahead) % trackPoints.length];

  // Steer toward target
  const toTarget = new THREE.Vector3(target.x - ai.pos.x, 0, target.z - ai.pos.z).normalize();
  const fwd = new THREE.Vector3(Math.sin(ai.angle), 0, Math.cos(ai.angle));
  const cross = fwd.x * toTarget.z - fwd.z * toTarget.x;

  ai.angVel += -cross * 3 * dt;
  ai.angVel *= 0.85;
  ai.angle += ai.angVel;

  // Speed - vary per AI
  const targetSpeed = (ai.def.topSpeed / 3.6) * (0.7 + Math.random() * 0.1);
  const fwdVec = new THREE.Vector3(Math.sin(ai.angle), 0, Math.cos(ai.angle));
  const curSpeed = ai.vel.length();

  if (curSpeed < targetSpeed) ai.vel.add(fwdVec.clone().multiplyScalar(ai.def.accel * 0.6 * dt));
  ai.vel.multiplyScalar(0.99);

  // Lateral friction
  const right = new THREE.Vector3(Math.cos(ai.angle), 0, -Math.sin(ai.angle));
  const lat = right.clone().multiplyScalar(ai.vel.dot(right));
  ai.vel.sub(lat.multiplyScalar(0.3));

  ai.pos.add(ai.vel.clone().multiplyScalar(dt));
  ai.pos.y = 0.4;

  ai.mesh.position.copy(ai.pos);
  ai.mesh.rotation.y = ai.angle;

  // Wheel spin
  ai.mesh.wheels.forEach(w => w.mesh.children[0] && w.mesh.children[0].rotateX(curSpeed * dt * 3.0));
}

// ======================= LAP COUNTING =======================
let playerNearStart = false;
let lastLapCross = 0;

function updateLaps() {
  const startPt = trackPoints[0];
  const dist = new THREE.Vector2(carPos.x - startPt.x, carPos.z - startPt.z).length();
  const now = Date.now();

  if (dist < 12 && !playerNearStart && (now - lastLapCross) > 5000) {
    playerNearStart = true;
    if (raceStarted && currentLap <= totalLaps) {
      const lapTime = (now - lapStartTime) / 1000;
      if (currentLap > 1 && lapTime < bestLap) {
        bestLap = lapTime;
        const m = Math.floor(bestLap/60);
        const s = (bestLap % 60).toFixed(2).padStart(5,'0');
        document.getElementById('hud-bestlap').textContent = `${m}:${s}`;
      }
      lapStartTime = now;
      currentLap++;
      lastLapCross = now;

      if (currentLap > totalLaps) {
        endRace();
        return;
      }
      document.getElementById('hud-lap').textContent = `${Math.min(currentLap,totalLaps)} / ${totalLaps}`;
    }
  } else if (dist > 20) {
    playerNearStart = false;
  }
}

// ======================= POSITION =======================
function updatePosition() {
  const playerProg = getNearestTrackPoint(carPos);
  let ahead = 0;
  aiCars.forEach(ai => {
    if (getNearestTrackPoint(ai.pos) > playerProg) ahead++;
  });
  const pos = ahead + 1;
  const posStr = `P${pos}`;
  const posClass = pos===1 ? 'pos-1' : pos===2 ? 'pos-2' : pos===3 ? 'pos-3' : 'pos-n';
  document.getElementById('hud-pos').textContent = posStr;
  document.getElementById('hud-pos').className = 'ts-val ' + posClass;
  document.getElementById('big-pos').textContent = posStr;
  document.getElementById('big-pos').className = posClass;
  return pos;
}

// ======================= CAMERA =======================
const camOffset = new THREE.Vector3(0, 6, -14);
const camOffsetHood = new THREE.Vector3(0, 1.2, 1.0);
let camTarget = new THREE.Vector3();
let camCurrent = new THREE.Vector3();

function updateCamera() {
  const fwd = new THREE.Vector3(Math.sin(carAng), 0, Math.cos(carAng));
  const right = new THREE.Vector3(Math.cos(carAng), 0, -Math.sin(carAng));
  const up = new THREE.Vector3(0, 1, 0);

  if (camMode === 0) {
    // Chase cam - behind car with speed-based distance and FOV
    const speed = carVel.length();
    const distMult = 1 + speed * 0.025;
    const fovTarget = 70 + speed * 0.12; // FOV widens dramatically at speed
    camera.fov += (Math.min(130, fovTarget) - camera.fov) * 0.06;
    camera.updateProjectionMatrix();
    const desired = carPos.clone()
      .sub(fwd.clone().multiplyScalar(14 * distMult))
      .add(new THREE.Vector3(0, 5.5 + speed * 0.04, 0));
    camCurrent.lerp(desired, 0.07);
    camera.position.copy(camCurrent);
    camTarget.lerp(carPos.clone().add(new THREE.Vector3(0, 1.5, 0)).add(fwd.clone().multiplyScalar(10)), 0.1);
    camera.lookAt(camTarget);
  } else if (camMode === 1) {
    // Hood cam - very low and aggressive
    camera.fov += (80 - camera.fov) * 0.1;
    camera.updateProjectionMatrix();
    const speed = carVel.length();
    const desired = carPos.clone()
      .add(fwd.clone().multiplyScalar(0.8))
      .add(new THREE.Vector3(0, 1.05, 0));
    camera.position.lerp(desired, 0.3);
    camera.lookAt(carPos.clone().add(fwd.clone().multiplyScalar(40)).add(new THREE.Vector3(0, 0.5, 0)));
  } else {
    // Cinematic orbit
    const time = Date.now() * 0.0003;
    const orbitR = 20 + Math.sin(time) * 5;
    const orbitY = 8 + Math.sin(time*1.3) * 3;
    camera.position.set(
      carPos.x + Math.sin(time) * orbitR,
      carPos.y + orbitY,
      carPos.z + Math.cos(time) * orbitR
    );
    camera.lookAt(carPos.clone().add(new THREE.Vector3(0, 1, 0)));
  }
}

// ======================= MINIMAP =======================
function updateMinimap() {
  const canvas = document.getElementById('minimap-canvas');
  const ctx = canvas.getContext('2d');
  const W = canvas.width = 160, H = canvas.height = 160;
  ctx.clearRect(0,0,W,H);

  // Track
  ctx.strokeStyle = 'rgba(255,255,255,0.3)';
  ctx.lineWidth = 4;
  ctx.beginPath();
  const scale = 0.35;
  trackPoints.forEach((pt, i) => {
    const mx = W/2 + pt.x * scale;
    const my = H/2 + pt.z * scale;
    i === 0 ? ctx.moveTo(mx, my) : ctx.lineTo(mx, my);
  });
  ctx.closePath();
  ctx.stroke();

  // AI cars
  aiCars.forEach((ai, i) => {
    const colors = ['#ff4444','#44aaff','#44ff88','#ffaa44'];
    ctx.fillStyle = colors[i];
    ctx.beginPath();
    ctx.arc(W/2 + ai.pos.x*scale, H/2 + ai.pos.z*scale, 3, 0, Math.PI*2);
    ctx.fill();
  });

  // Player
  ctx.fillStyle = '#ffcc00';
  ctx.beginPath();
  ctx.arc(W/2 + carPos.x*scale, H/2 + carPos.z*scale, 5, 0, Math.PI*2);
  ctx.fill();
  ctx.strokeStyle = '#fff';
  ctx.lineWidth = 1.5;
  ctx.stroke();
}

// ======================= RACE TIMER =======================
function updateTimer() {
  const elapsed = (Date.now() - raceStartTime) / 1000;
  const mins = Math.floor(elapsed/60);
  const secs = (elapsed % 60).toFixed(1).padStart(4,'0');
  document.getElementById('hud-time').textContent = `${mins}:${secs}`;
}

// ======================= END RACE =======================
function endRace() {
  raceEnded = true;
  raceStarted = false;
  const pos = updatePosition();
  const track = TRACK_DEFS.find(t=>t.id===selectedTrackId);
  const rewards = [1, 0.6, 0.3, 0.1];
  const reward = Math.round(track.reward * (rewards[pos-1] || 0.05));
  cash += reward;

  const overlay = document.getElementById('race-result');
  const title = document.getElementById('result-title');
  title.textContent = pos === 1 ? '🏆 WINNER!' : `P${pos} PLACE`;
  title.className = pos === 1 ? 'result-win' : 'result-lose';
  document.getElementById('result-detail').textContent = `${track.name} · ${pos}${pos===1?'st':pos===2?'nd':pos===3?'rd':'th'} Place`;
  document.getElementById('result-reward').textContent = `+$${reward.toLocaleString()} earned`;
  overlay.style.display = 'flex';
}

// ======================= COUNTDOWN =======================
function startCountdown() {
  let count = 3;
  const el = document.getElementById('countdown');
  const num = document.getElementById('countdown-num');
  el.style.display = 'flex';

  const tick = () => {
    num.textContent = count;
    num.style.animation = 'none';
    void num.offsetWidth;
    num.style.animation = 'countAnim 0.9s ease-out';

    if (count <= 0) {
      num.textContent = 'GO!';
      num.style.animation = 'none';
      void num.offsetWidth;
      num.style.animation = 'countAnim 0.7s ease-out';
      setTimeout(() => {
        el.style.display = 'none';
        raceStarted = true;
        raceStartTime = Date.now();
        lapStartTime = Date.now();
        currentLap = 1;
      }, 700);
      return;
    }
    count--;
    setTimeout(tick, 900);
  };
  tick();
}

// ======================= SPEED LINES =======================
let speedLineCanvas, speedLineCtx;
const speedLines = [];
function initSpeedLines() {
  speedLineCanvas = document.getElementById('speed-overlay');
  speedLineCtx = speedLineCanvas.getContext('2d');
  speedLineCanvas.width = window.innerWidth;
  speedLineCanvas.height = window.innerHeight;
  window.addEventListener('resize', () => {
    speedLineCanvas.width = window.innerWidth;
    speedLineCanvas.height = window.innerHeight;
  });
  for (let i = 0; i < 80; i++) {
    speedLines.push({
      angle: Math.random() * Math.PI * 2,
      dist: 0.2 + Math.random() * 0.45,
      len: 0.02 + Math.random() * 0.06,
      speed: 0.3 + Math.random() * 0.7,
      width: 0.5 + Math.random() * 1.5,
    });
  }
}

function updateSpeedLines() {
  if (!raceStarted || raceEnded || !speedLineCanvas) return;
  const W = speedLineCanvas.width, H = speedLineCanvas.height;
  const cx = W/2, cy = H/2;
  const maxR = Math.max(W, H) * 0.55;

  const speedFactor = Math.min(1, carSpeed / 500);
  speedLineCanvas.style.opacity = speedFactor > 0.3 ? (speedFactor - 0.3) * 1.4 : 0;

  speedLineCtx.clearRect(0, 0, W, H);
  if (speedFactor < 0.3) return;

  speedLines.forEach(line => {
    line.dist += line.speed * speedFactor * 0.008;
    if (line.dist > 0.75) { line.dist = 0.1 + Math.random() * 0.15; line.angle = Math.random() * Math.PI * 2; }

    const r1 = line.dist * maxR;
    const r2 = (line.dist + line.len * speedFactor) * maxR;
    const x1 = cx + Math.cos(line.angle) * r1;
    const y1 = cy + Math.sin(line.angle) * r1;
    const x2 = cx + Math.cos(line.angle) * r2;
    const y2 = cy + Math.sin(line.angle) * r2;

    const alpha = (speedFactor - 0.3) * 0.6 * (line.dist * 2);
    speedLineCtx.strokeStyle = `rgba(200,220,255,${alpha})`;
    speedLineCtx.lineWidth = line.width;
    speedLineCtx.beginPath();
    speedLineCtx.moveTo(x1, y1);
    speedLineCtx.lineTo(x2, y2);
    speedLineCtx.stroke();
  });
}

// ======================= MAIN GAME LOOP =======================
function animate() {
  requestAnimationFrame(animate);
  const dt = Math.min(clock.getDelta(), 0.05);

  if (raceStarted && !raceEnded) {
    updatePlayerCar(dt);
    aiCars.forEach(ai => updateAICar(ai, dt));
    updateLaps();
    updatePosition();
    updateCamera();
    updateMinimap();
    updateTimer();
    document.getElementById('hud-cash').textContent = '$' + cash.toLocaleString();
  } else if (!raceStarted) {
    // Idle camera orbit around car
    if (playerCar) {
      const t = Date.now() * 0.0004;
      camera.position.set(
        carPos.x + Math.sin(t) * 18,
        carPos.y + 7,
        carPos.z + Math.cos(t) * 18
      );
      camera.lookAt(carPos.clone().add(new THREE.Vector3(0,1,0)));
    }
  }

  renderer.render(scene, camera);
  updateSpeedLines();
}

// ======================= BEGIN RACE =======================
function beginRace() {
  document.getElementById('start-screen').style.display = 'none';
  document.getElementById('hud').style.display = 'block';
  document.getElementById('hud-lap').textContent = `1 / ${totalLaps}`;

  // Show touch controls on touch devices (phones/tablets); hide on laptop/desktop
  const isTouch = isTouchDevice();
  const touchCtrl = document.getElementById('touch-controls');
  // Use CSS @media(pointer:fine) to auto-hide on laptop, but also JS override
  if (touchCtrl) touchCtrl.style.display = isTouch ? 'block' : 'none';

  initThree();
  generateTrackPoints();
  setupLighting(selectedTrackId);
  buildTrack(selectedTrackId);
  spawnCars();
  setupTouchControls();

  minimapCtx = document.getElementById('minimap-canvas').getContext('2d');
  initSpeedLines();

  animate();
  startCountdown();
}

// ======================= INIT =======================
setupStartScreen();

# ⚡ Velocity Empire 3D

A free, open-source **3D browser racing game** built with Three.js. No download, no install — just open in a browser and race.

🎮 **[Play Now →](https://YOUR-USERNAME.github.io/velocity-empire)**

---

## 🚗 Features

- **6 photorealistic supercars** — Honda Civic Type R, Shelby GT500, BMW M4 CSL, Ferrari SF90, Lamborghini Aventador, Bugatti Bolide (1000 km/h!)
- **3 unique tracks** — City Circuit, Desert Track, Night Race
- **Full 3D graphics** — detailed car models with brake calipers, LED headlights, spoilers, interiors
- **Realistic physics** — weight, drift, lateral friction, handbrake
- **Speed effects** — dynamic FOV, speed lines, exhaust glow
- **3 camera modes** — Chase, Hood, Cinematic orbit

---

## 📱 Platform Support

| Platform | Controls |
|---|---|
| 💻 Laptop / Desktop | `W/A/S/D` or Arrow Keys · `SHIFT` Nitro · `SPACE` Handbrake · `R` Reset · `C` Camera |
| 📱 Phone / Tablet | Virtual joystick + on-screen buttons |
| 📐 iPhone / Android | Tilt-to-steer (gyroscope) — tap the TILT button |
| 🎮 Controller | Xbox / PlayStation / any standard gamepad |
| 📟 iPad | Full touch support with safe-area insets |

---

## 🚀 Deploy to GitHub Pages (5 minutes)

### Option 1 — GitHub Web UI (easiest)

1. Click **"Use this template"** or **Fork** this repo
2. Go to **Settings → Pages**
3. Under **Source**, select **`main` branch** and **`/ (root)`** folder
4. Click **Save**
5. Your game will be live at `https://YOUR-USERNAME.github.io/velocity-empire` within ~60 seconds

### Option 2 — Clone and push

```bash
# Clone this repo
git clone https://github.com/YOUR-USERNAME/velocity-empire.git
cd velocity-empire

# (Optional) Make changes, then push
git add .
git commit -m "My changes"
git push origin main
```

GitHub Pages will auto-deploy on every push to `main`.

---

## 📁 Project Structure

```
velocity-empire/
├── index.html          ← Main game page (GitHub Pages entry point)
├── css/
│   └── game.css        ← All styles (HUD, touch controls, responsive)
├── js/
│   └── game.js         ← All game logic (Three.js, physics, AI, input)
├── _config.yml         ← GitHub Pages config
└── README.md           ← This file
```

---

## 🛠️ Local Development

No build tools needed. Just open `index.html` in any browser:

```bash
# Option A — Python (built into macOS/Linux)
python3 -m http.server 8080
# then open http://localhost:8080

# Option B — Node.js
npx serve .
# then open http://localhost:3000

# Option C — VS Code
# Install "Live Server" extension → right-click index.html → "Open with Live Server"
```

> ⚠️ **Do not open index.html directly as a `file://` URL** — browsers block some features (like fonts and module imports) on file:// origins. Use a local server instead.

---

## 🎨 Customisation

### Change car colors
In `js/game.js`, find `CAR_DEFS` near the top:
```js
{ id:'ferrari', name:'Ferrari SF90', color:0xff1100, topSpeed:720, ... }
//                                         ^^^^^^^^ hex color
```

### Change speeds
```js
{ id:'bugatti', name:'Bugatti Bolide', topSpeed:1000, accel:160, ... }
//                                              ^^^^         ^^^
```

### Add a new track
In `TRACK_DEFS`:
```js
{ id:'mytrack', name:'My Track', laps:3, reward:8000, color:0x334455 }
```

---

## 🧰 Tech Stack

| Library | Version | Purpose |
|---|---|---|
| [Three.js](https://threejs.org) | r128 | 3D rendering, WebGL |
| Vanilla JS | ES2020 | Game logic, physics |
| CSS3 | — | HUD, responsive layout |

No frameworks, no bundlers, no npm required.

---

## 📜 License

MIT — free to use, modify, and share.

---

## 🙏 Credits

Built with [Three.js](https://threejs.org) · Fonts by [Google Fonts](https://fonts.google.com)
